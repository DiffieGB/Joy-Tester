var hierarchy =
[
    [ "CodX.VJoy.VirtualJoystick.IButton", "interface_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_i_button.html", [
      [ "CodX.VJoy.VirtualJoystick.Button", "class_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_button.html", null ]
    ] ],
    [ "CodX.VJoy.VirtualJoystick.IPad", "interface_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_i_pad.html", [
      [ "CodX.VJoy.VirtualJoystick.AnalogPad", "class_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_analog_pad.html", null ]
    ] ],
    [ "CodX.VJoy.VirtualJoystick.IVJControl", "interface_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_i_v_j_control.html", [
      [ "CodX.VJoy.VirtualJoystick.AnalogPad", "class_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_analog_pad.html", null ],
      [ "CodX.VJoy.VirtualJoystick.Button", "class_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_button.html", null ],
      [ "CodX.VJoy.VirtualJoystick.Toggle", "class_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_toggle.html", null ]
    ] ],
    [ "MonoBehaviour", null, [
      [ "CodX.VJoy.VirtualJoystick", "class_cod_x_1_1_v_joy_1_1_virtual_joystick.html", null ]
    ] ]
];