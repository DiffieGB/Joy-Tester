var interface_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_i_pad =
[
    [ "GetAxes", "interface_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_i_pad.html#ac172e62ce16bf95102bb908cadfed3e6", null ],
    [ "GetAxis", "interface_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_i_pad.html#acf137661d8843abcb946e3b90600174b", null ]
];