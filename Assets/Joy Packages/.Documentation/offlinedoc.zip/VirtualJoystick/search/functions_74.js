var searchData=
[
  ['touchcoords',['TouchCoords',['../class_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_button.html#aba55b60bce2c6012ab5d720d6b87fa32',1,'CodX.VJoy.VirtualJoystick.Button.TouchCoords()'],['../class_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_toggle.html#aac40f93d68ca9f5ff9cc94cc1c603c16',1,'CodX.VJoy.VirtualJoystick.Toggle.TouchCoords()']]]
];
