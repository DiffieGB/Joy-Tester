var searchData=
[
  ['init',['Init',['../interface_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_i_v_j_control.html#a5ac786e831d0a350762b1df334359e82',1,'CodX.VJoy.VirtualJoystick.IVJControl.Init()'],['../class_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_analog_pad.html#ab6debfdfbd90cffb5fa075a11597ba48',1,'CodX.VJoy.VirtualJoystick.AnalogPad.Init()'],['../class_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_button.html#ae3799b2100600ac03a54db1326f82b88',1,'CodX.VJoy.VirtualJoystick.Button.Init()'],['../class_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_toggle.html#a44681c011159aafd20df2e48e70ffbb3',1,'CodX.VJoy.VirtualJoystick.Toggle.Init()']]],
  ['initall',['InitAll',['../class_cod_x_1_1_v_joy_1_1_virtual_joystick.html#a77c455811559ab5fb5aa9c55a14a6c59',1,'CodX::VJoy::VirtualJoystick']]]
];
