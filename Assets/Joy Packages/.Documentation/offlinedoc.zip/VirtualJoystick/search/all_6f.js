var searchData=
[
  ['onbuttonchanged',['OnButtonChanged',['../class_cod_x_1_1_v_joy_1_1_virtual_joystick.html#afc2a61b08833714f50c30aa7df46ed12',1,'CodX::VJoy::VirtualJoystick']]],
  ['onpadchanged',['OnPadChanged',['../class_cod_x_1_1_v_joy_1_1_virtual_joystick.html#a44e4bf1d97ac30318183ec70a7949c72',1,'CodX::VJoy::VirtualJoystick']]],
  ['ontogglechanged',['OnToggleChanged',['../class_cod_x_1_1_v_joy_1_1_virtual_joystick.html#a839672a8035136cee3479969fff1e894',1,'CodX::VJoy::VirtualJoystick']]]
];
