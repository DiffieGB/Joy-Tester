var interface_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_i_button =
[
    [ "GetButton", "interface_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_i_button.html#a8a441a48a1972af90e9f7bccd15560d3", null ],
    [ "GetButtonDown", "interface_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_i_button.html#ac84e42a7060fad6b8734a45a5f23d459", null ],
    [ "GetButtonUp", "interface_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_i_button.html#a3235ab56ed101faeb6ccbd9792459f2e", null ]
];