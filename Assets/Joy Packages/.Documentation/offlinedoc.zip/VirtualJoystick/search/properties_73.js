var searchData=
[
  ['status',['status',['../class_cod_x_1_1_v_joy_1_1_virtual_joystick_1_1_toggle.html#a0c4889a727c820f5e9f1ca82041aa954',1,'CodX::VJoy::VirtualJoystick::Toggle']]]
];
